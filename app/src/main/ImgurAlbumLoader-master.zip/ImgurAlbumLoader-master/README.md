# ImgurAlbumLoader
Change `AlbumImageLinksFetcher.IMGUR_CLIENT_ID` to your own ID and `AlbumImageLinksFetcher.ALBUM_ID` to the desired album ID.

**OH AND REMEMBER TO DELETE THIS README JUST IN CASE BEFORE SUBMISSION**